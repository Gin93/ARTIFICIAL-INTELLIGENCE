domain   | instance | R-t without hadm | Node-expan without hadm | Len without hadm|| Run-time with hadm| Node expansion with hadm| Len with hadm
logistics| task01   | 0.66		       | 12348				     | 20			   || 0.21              |  398                    | 20
logistics| task02   | 0.53		       | 10592					 | 19			   || 0.24              |  540                    | 19
logistics| task03   | 0.25		       | 5004					 | 15			   || 0.052             |  121                    | 15
logistics| task04   | 7.1		       | 115393					 | 27			   || 2.2               |  3555                   | 27
logistics| task05   | 1.6		       | 26963					 | 17			   || 0.29              |  508                    | 17
logistics| task06   | 0.069		       | 1211					 | 8			   || 0.021             |  32                     | 8
logistics| task07   | 38		       | 497902					 | 25			   || 2.6               |  3471                   | 25
logistics| task08   | 2.1		       | 30480					 | 14			   || 0.12              |  124                    | 14
logistics| task09   | 37		       | 497902					 | 25			   || 1.6               |  2054                   | 25
logistics| task10   | 32		       | 43295					 | 24			   || 1.1               |  1540                   | 24
logistics| task11   | ****		                                           

domain   | instance | R-t without hadm | Node-expan without hadm | Len without hadm|| Run-time with hadm| Node expansion with hadm| Len with hadm
blocks   |   task01	| 0.0034		   | 102				     | 6			   || 0.0063            |  10                     | 6
blocks   |   task02	| 0.003			   | 70						 | 10			   || 0.0058            |  14                     | 10
blocks   |   task03	| 0.0027		   | 66						 | 6			   || 0.0046            |  9                      | 6
blocks   |   task04	| 0.019			   | 587					 | 12			   || 0.019             |  35                     | 12
blocks   |   task05	| 0.02			   | 575					 | 10			   || 0.022             |  36                     | 10
blocks   |   task06	| 0.023		       | 799					 | 16			   || 0.062             |  89                     | 16
blocks   |   task07	| 0.086			   | 2166					 | 12			   || 0.029             |  24                     | 12
blocks   |   task08	| 0.19			   | 4922					 | 10			   || 0.021             |  17                     | 10
blocks   |   task09	| 0.24			   | 6688					 | 20			   || 0.042             |  521                    | 20
blocks   |   task10 | 1.8			   | 38689					 | 20			   || 0.21              |  167                    | 20
blocks   |   task11 | 2.9			   | 64677					 | 22			   || 3.8               |  3698                   | 22
blocks   |   task12	| 2.8			   | 59168					 | 20			   || 1.3               |  751                    | 20
blocks   |   task13	| 33			   | 531358					 | 18			   || 1.2               |  755                    | 18
blocks   |   task14	| 40			   | 638232					 | 20			   || 5.0               |  3452                   | 20
blocks   |   task15	| 27			   | 439350					 | 16			   || 0.43              |  258                    | 16
blocks   |   task15	| ****			   

****: cannot be solved within 3 mins,  it's always killed by System.
A possible reason is I am running the program in LINUX via VMware
If you are interested in these very large cases, you can test in your desktop,
I consider the hadm can reduce the run-time a lots



Conclusion:
We can see a reasonable reduction in the number of nodes with overall run time saving (compared with the blind heuristic) for the majority of the
instances under consideration (especially the large ones).
For all cases, hadm can reduce nodes expansion siginificantly
For large case, hadm can reduce the running-time siginificantly

Interpretation:
hadm can reduce the node expansion siginificantly, but for calculating each hadm(node), it will consume much more time than blind heuristic.

When the case is small, there is no relatively siginificant difference between the node expansion for running blind heuristic and hadm 
Therefore, the running-time is close. But for a large case. The difference between the node expansion is huge, 
therefore the running-time can be reduced siginificantly


