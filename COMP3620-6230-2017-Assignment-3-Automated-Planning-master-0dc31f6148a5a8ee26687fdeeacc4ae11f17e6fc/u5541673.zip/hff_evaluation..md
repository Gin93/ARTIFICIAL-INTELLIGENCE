domain   |   instance  | Run-time without Hff| Node expansion without Hff| Len without Hff|| Run-time with Hff| Node expansion with Hff| Len with Hff
blocks   |   task01	   | 0.0034				 | 79						 | 6			  || 0.0047           |  7                     | 6
blocks   |   task02	   | 0.0024				 | 62						 | 10			  || 0.0053           |  12                    | 10
blocks   |   task03	   | 0.0027				 | 61						 | 6			  || 0.0038           |  7                     | 6
blocks   |   task04	   | 0.015				 | 468						 | 12			  || 0.011            |  19                    | 12
blocks   |   task05	   | 0.015				 | 482						 | 10			  || 0.013            |  25                    | 10
blocks   |   task06	   | 0.023				 | 750						 | 16			  || 0.021            |  47                    | 24
blocks   |   task07	   | 0.076				 | 1976						 | 12			  || 0.02             |  29                    | 12
blocks   |   task08	   | 0.17				 | 4658						 | 10			  || 0.03             |  41                    | 18
blocks   |   task09	   | 0.22				 | 6598						 | 20			  || 0.041            |  60                    | 32
blocks   |   task10	   | 1.6				 | 36831					 | 20			  || 0.026            |  32                    | 22
blocks   |   task11	   | 2.6				 | 63913					 | 22			  || 0.061            |  78                    | 34
blocks   |   task12	   | 2.3				 | 58533					 | 20			  || 0.11             |  149                   | 34
blocks   |   task13	   | 29				 	 | 519654					 | 18			  || 0.25             |  248                   | 34
blocks   |   task14	   | 35				 	 | 629303					 | 20			  || 0.12             |  115                   | 32
blocks   |   task15	   | 22					 | 390182					 | 16			  || 0.11             |  59                    | 22


pegsol   |   task13	   | 0.00075				 | 11					 | 5			  || 0.0033            |  8                    | 2
pegsol   |   task02	   | 0.0053					 | 83					 | 9			  || 0.017             |  22                   | 9
pegsol   |   task03	   | 0.013					 | 220					 | 9			  || 0.017             |  15                   | 9
pegsol   |   task04	   | 0.013				     | 228					 | 10			  || 0.037             |  58                   | 11
pegsol   |   task05	   | 0.017					 | 296					 | 11			  || 0.028             |  31                   | 12
pegsol   |   task06	   | 0.097					 | 1547					 | 12			  || 0.044             |  30                   | 16
pegsol   |   task07	   | 0.026					 | 413					 | 12			  || 0.017             |  19                   | 13
pegsol   |   task08	   | 2.4					 | 36660				 | 16			  || 0.18              |  119                  | 20
pegsol   |   task09	   | 0.26					 | 4266					 | 15			  || 0.29              |  330                  | 18
pegsol   |   task10	   | 2.1					 | 43315				 | 17			  || 0.12              |  110                  | 22
pegsol   |   task11	   | 0.92					 | 14477				 | 18			  || 0.34              |  415                  | 19
pegsol   |   task12	   | 2.8					 | 40879				 | 20			  || 0.037             |  29                   | 23
pegsol   |   task13	   | 2.1					 | 33645				 | 21			  || 0.23              |  165                  | 23
pegsol   |   task14	   | 4.5					 | 67710				 | 20			  || 0.68              |  691                  | 25
pegsol   |   task15	   | 5.5					 | 81955				 | 21			  || 0.13              |  69                   | 26

Conclusion: For large case, Hff can reduce the running-time and nodes expansion siginificantly

Interpretation:
Hff can reduce the node expansion siginificantly, but for calculating each Hff(node), it will consume much more time than blind heuristic.
When the case is small, for example BLOCKS TASK06 750 nodes expanded when using blind heuristic, while 47 nodes expanded when using 
Hff. There is no relatively siginificant difference between 750 and 47. Therefore, the running-time is close 0.023s and 0.026s
But for a large case, like BLOCKS TASK14, 629303 nodes expanded when using blind heuristic, while only 115 nodes expanded when using 
Hff. The  difference between them is huge, therefore the running-time can be reduced siginificantly


